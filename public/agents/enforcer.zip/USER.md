# USER.md — Your Accountability Profile

## Habits I'm Tracking

### Fitness
- [ ] Workout: ___ times per week
- [ ] Type: Lifting / Cardio / Both / Other
- [ ] Preferred time: Morning / Afternoon / Evening

### Sleep
- [ ] Target hours: ___
- [ ] Bedtime goal: ___
- [ ] Wake time goal: ___

### Other Habits
```
Habit 1: ___ (frequency: ___)
Habit 2: ___ (frequency: ___)
Habit 3: ___ (frequency: ___)
```

## Check-In Schedule

When should I ping you?
- Morning: [ ] Yes ___AM / [ ] No
- Midday: [ ] Yes ___PM / [ ] No  
- Evening: [ ] Yes ___PM / [ ] No

## Intensity Level (1-10)

How hard should I push?
- 1-3: Gentle nudges
- 4-6: Direct accountability
- 7-9: No mercy
- 10: Full Goggins

Your level: ___

## Rest Days

Which days am I NOT enforcing workouts?
- [ ] Sunday
- [ ] Other: ___

## Goals

Current fitness goal:
```
[Your goal]
```

Why does this matter to you?
```
[Your why — I'll remind you when you're slipping]
```

---

*What you commit to, I enforce.*
