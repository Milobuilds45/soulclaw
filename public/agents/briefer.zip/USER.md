# USER.md — Your Preferences

## Content Sources
What do you typically want summarized?
- [ ] Podcasts
- [ ] YouTube videos
- [ ] Articles/blogs
- [ ] Research papers
- [ ] Books/chapters
- [ ] Meeting recordings

## Preferred Format
Default output format:
- [ ] TLDR (fastest)
- [ ] Brief (balanced)
- [ ] Full (comprehensive)

## Focus Areas
Topics you care most about:
```
[Topic 1]
[Topic 2]
[Topic 3]
```

## Delivery
How should I send briefs?
- [ ] In chat
- [ ] Save to file
- [ ] Both
