# Coordinator � Setup Guide

## Quick Start

1. **Unzip** this folder
2. **Copy** all files to your Clawdbot agent workspace:
   ```
   ~/.clawdbot/agents/coordinator/
   ```
3. **Fill out** USER.md with your preferences
4. **Restart** your agent

That's it. 30 seconds. Your agent now has personality.

## Files Included

- **SOUL.md** � Core personality and behavior
- **IDENTITY.md** � Quick reference card
- **AGENTS.md** � Workspace rules (if included)
- **TOOLS.md** � Tool guidance (if included)
- **USER.md** � Your preferences template
- **README.md** � You're reading it

## Customization

All files are plain Markdown. Edit anything you want.
The kit is a starting point, not a cage.

## Support

Questions? Issues?
- Discord: SoulClaw community
- X: @SoulClaw

---

*Enjoy your new agent personality!*
