# The Ghostwriter — Setup Guide

Your AI-powered brand proxy. Builds your presence while you sleep.

## Quick Start

### 1. Unzip this folder
Place it in your Clawdbot agents directory:
```
~/.clawdbot/agents/ghostwriter/
```
Or wherever you keep your agent workspaces.

### 2. Fill out USER.md
This is critical. The more you tell me about yourself:
- Your voice and tone
- Your hot takes
- Your content pillars
- Your no-fly zones

...the better I match you.

### 3. Feed me voice samples
Create a `voice-samples/` folder and add:
- **tweets.md** — Export 50+ of your past tweets
- **threads.md** — Your best performing threads
- **hot-takes.md** — Strong opinions you hold

### 4. Configure Clawdbot
Point Clawdbot to this agent workspace. The SOUL.md and AGENTS.md will load automatically.

### 5. Set approval mode
In USER.md, choose:
- **Full Auto** — I engage freely
- **Queue Review** — I draft, you approve
- **Suggestion Only** — I suggest, you write

## File Structure

```
ghostwriter/
├── SOUL.md         # My personality (don't edit unless customizing)
├── AGENTS.md       # Workspace rules
├── TOOLS.md        # Platform-specific notes
├── IDENTITY.md     # Quick reference card
├── USER.md         # ⚠️ FILL THIS OUT
├── README.md       # You're reading it
├── voice-samples/  # Your past content (create this)
├── memory/         # My daily logs (auto-created)
└── content-queue/  # Draft pipeline (auto-created)
```

## How I Work

### Proactive (Default)
- Scan your timeline for opportunities
- Find conversations to join
- Draft replies in your voice
- Track what's working

### On-Demand
- "Write a thread about X"
- "Reply to this tweet"
- "Roast this take"

## Tips for Best Results

1. **More samples = better voice match** — 50+ tweets minimum
2. **Be specific about your no-fly zones** — I respect boundaries
3. **Review my first few posts** — Correct me early, I learn fast
4. **Check memory logs** — See what I'm learning about your audience

## Customization

Feel free to edit any file to adjust my behavior:
- SOUL.md — Core personality
- AGENTS.md — Workspace rules
- TOOLS.md — Platform settings
- USER.md — Your profile

## Support

Questions? Issues? 
- Discord: [SoulClaw Discord]
- X: @SoulClaw

---

*Let's build your tribe.*

— The Ghostwriter
