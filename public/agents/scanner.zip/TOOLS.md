# TOOLS.md — The Scanner

## Data Sources

### Market Data
- **Yahoo Finance** — Quotes, charts, fundamentals
- **TradingView** — Technical analysis, alerts
- **Finviz** — Screeners, heatmaps
- **Unusual Whales** — Options flow (if subscribed)
- **Barchart** — Futures, commodities

### News & Filings
- **SEC EDGAR** — Insider filings, 13Fs
- **Earnings calendars** — Know what's reporting
- **News APIs** — Real-time headlines
- **PR Newswire** — Corporate announcements

### Crypto
- **CoinGecko/CoinMarketCap** — Prices, volume
- **Glassnode/Nansen** — On-chain (if subscribed)
- **Whale Alert** — Large transactions
- **DeFi Llama** — TVL, protocol data

### Social/Sentiment
- **X/Twitter** — CT, influencer tracking
- **Reddit** — WSB, sector subs
- **StockTwits** — Retail sentiment
- **Discord** — Alpha groups (your access)

## Scan Techniques

### Unusual Options Activity
Look for:
- Volume > 5x average
- OTM calls with size
- Sweeps vs blocks
- Expiration clustering

### Technical Setups
- Breakouts above resistance
- Breakdowns below support
- Volume confirmation
- RSI extremes (oversold/overbought)

### Sentiment Extremes
- Fear/Greed index readings
- Put/call ratios
- Social mention spikes
- Crowded trades (everyone on one side)

### Smart Money Tracking
- 13F filings (quarterly, delayed)
- Insider buying/selling (Form 4)
- Whale wallet movements (crypto)
- Dark pool prints

## Alert Templates

### Red Alert
```
🔴 RED ALERT — [TICKER]

WHAT: [Description]
SOURCE: [Where/How I found it]
CONFIDENCE: High/Medium/Low
TIME SENSITIVITY: Immediate/Hours/Days
RISK: [Downside scenario]
ACTION WINDOW: [When this expires]

[Evidence/Links]
```

### Yellow Alert
```
🟡 NOTABLE — [TICKER/TOPIC]

WHAT: [Description]
WHY IT MATTERS: [Context]
WATCH FOR: [Trigger that escalates this]

[Source]
```

### Green (FYI)
```
🟢 FYI — [Topic]

[Brief note for future reference]
```

## Filters & Noise Reduction

### Auto-Ignore
- Market cap < $100M (unless specifically watching)
- Volume < 100K (illiquid)
- Penny stocks (unless specified)
- Obvious pump & dumps
- Recycled news (>4 hours old)

### Require Verification
- Anonymous X accounts
- Single-source stories
- "Insider" claims
- Too-good-to-be-true setups

## Time Zones

All times in ET (Eastern) unless specified.
- Pre-market: 4:00 AM - 9:30 AM
- Regular: 9:30 AM - 4:00 PM
- After-hours: 4:00 PM - 8:00 PM
- Crypto: 24/7

## API Keys (If Applicable)

```
# Add your keys here if using APIs
ALPHA_VANTAGE_KEY=
POLYGON_KEY=
TWITTER_BEARER=
```

## Integration

Works best with:
- Telegram alerts (instant push)
- Trading journal (execution tracking)
- Spreadsheet (position management)
