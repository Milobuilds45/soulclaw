# USER.md — Your Trading Profile

Fill this out so I know what to scan for.

## Watchlist

### Equities
```
SPY, QQQ, AAPL, NVDA, TSLA
[Add your tickers]
```

### Crypto
```
BTC, ETH, SOL
[Add your coins]
```

### Futures
```
ES, NQ, VIX
[Add if you trade futures]
```

### Sectors to Watch
```
AI, semiconductors, energy
[Your sectors of interest]
```

## X/CT Accounts to Monitor

Who do you follow for alpha?
```
@[account1]
@[account2]
@[account3]
```

## Trading Style

### Timeframe
- [ ] Scalping (minutes)
- [ ] Day trading (hours)
- [ ] Swing trading (days-weeks)
- [ ] Position trading (weeks-months)
- [ ] Investing (months-years)

### Risk Tolerance
- [ ] Conservative (high conviction only)
- [ ] Moderate (calculated risks)
- [ ] Aggressive (swing at opportunities)
- [ ] Degen (full send, NFA)

### Position Sizing
- Max single position: [X]% of portfolio
- Max sector exposure: [X]%
- Max correlation: [notes]

## Alert Preferences

### Sensitivity
- [ ] High (more alerts, some noise)
- [ ] Medium (balanced)
- [ ] Low (only high conviction)

### Quiet Hours
Don't alert me between:
- Start: [time]
- End: [time]
- Exception: 🔴 RED alerts always come through

### Delivery
- [ ] Telegram
- [ ] Discord
- [ ] Email
- [ ] In-app only

## Filters

### Market Cap Floor
Minimum market cap to scan: $[X]M

### Volume Floor
Minimum daily volume: [X]K

### Ignore List
Tickers/topics I don't care about:
```
[TICKER1]
[TICKER2]
```

## Goals

What are you trying to achieve?
- [ ] Catch momentum moves
- [ ] Find undervalued setups
- [ ] Track smart money
- [ ] Hedge existing positions
- [ ] Learn market mechanics
- [ ] Other: [describe]

## Notes

Anything else I should know about how you trade?

```
[Your notes]
```

---

*Configure me. I'll find your signals.*
