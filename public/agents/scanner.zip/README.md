# The Scanner — Setup Guide

Your AI-powered alpha radar. Finds signals while you sleep.

## Quick Start

### 1. Unzip this folder
Place it in your Clawdbot agents directory:
```
~/.clawdbot/agents/scanner/
```

### 2. Fill out USER.md
Critical configuration:
- Your watchlist (tickers, crypto, sectors)
- X accounts you follow for alpha
- Trading style and risk tolerance
- Alert preferences

### 3. Configure alerts
Set up Telegram/Discord integration for instant alerts.
Red alerts should ping you anywhere.

### 4. Let it scan
I start working immediately:
- Pre-market scans
- Real-time monitoring during market hours
- Overnight crypto/news watch

## File Structure

```
scanner/
├── SOUL.md         # My personality
├── AGENTS.md       # Workspace rules
├── TOOLS.md        # Data sources, APIs
├── IDENTITY.md     # Quick reference
├── USER.md         # ⚠️ FILL THIS OUT
├── README.md       # You're reading it
├── memory/         # Daily scan logs (auto-created)
├── signals/        # Alert archive (auto-created)
└── performance/    # Track record (auto-created)
```

## Alert Tiers

🔴 **RED ALERT** — Drop everything. Time-sensitive.
🟡 **YELLOW** — Notable. Worth attention when you can.
🟢 **GREEN** — FYI. File away for later.

## How I Work

### Proactive Scanning
- Pre-market gaps and news
- Unusual options activity
- Social sentiment spikes
- Smart money movements
- Technical breakouts/breakdowns

### On-Demand
- "What's moving in tech?"
- "Sentiment on NVDA?"
- "Any whale activity in BTC?"

## Tips for Best Results

1. **Keep watchlist focused** — 20-30 tickers max. Too many = noise.
2. **Set quiet hours** — Unless it's a red alert, I'll wait.
3. **Review my track record** — Check `performance/` to see my hit rate.
4. **Tune sensitivity** — Start medium, adjust based on signal quality.

## Important Disclaimers

- I am NOT financial advice
- I surface signals, YOU make decisions
- Past signals don't guarantee future results
- Always do your own research
- Position size responsibly

## Customization

Edit any file to adjust my behavior:
- SOUL.md — Personality and approach
- TOOLS.md — Data sources
- USER.md — Your preferences

## Support

Questions? Issues?
- Discord: [SoulClaw Discord]
- X: @SoulClaw

---

*Signal over noise. Let's find alpha.*

— The Scanner
