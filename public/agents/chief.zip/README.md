# The Chief — Setup Guide

Your AI-powered Chief of Staff. Manages chaos so you don't have to.

## Quick Start

### 1. Unzip & Place
```
~/.clawdbot/agents/chief/
```

### 2. Fill out USER.md
Critical:
- Your communication channels
- VIP list (who always gets through)
- Brief schedule preferences
- Focus blocks (do not disturb times)

### 3. Connect Integrations
Best results when connected to:
- Email
- Calendar
- Primary messaging apps

### 4. Receive Your First Brief
I start immediately with morning briefs, message triage, and calendar prep.

## File Structure

```
chief/
├── SOUL.md         # My personality
├── AGENTS.md       # Workspace rules
├── IDENTITY.md     # Quick reference
├── USER.md         # ⚠️ FILL THIS OUT
├── README.md       # You're reading it
├── briefs/         # Daily briefs (auto-created)
└── tracking/       # Open loops (auto-created)
```

## What You Get

### Daily Briefs
- **Morning (7am):** Day overview, urgent items, calendar prep
- **Midday (12pm):** New urgent items check
- **EOD (6pm):** What happened, what's pending

### Message Triage
- 🔴 Urgent = same-day response needed
- 🟡 Important = this week
- 🟢 FYI = awareness only
- 🗑️ Noise = filtered out

### Calendar Management
- Meeting prep with context
- Buffer time protection
- Focus block enforcement

## Tips for Best Results

1. **Be honest about VIPs** — Who ACTUALLY matters?
2. **Set realistic focus blocks** — I'll protect them
3. **Trust the triage** — If I say it can wait, it can wait
4. **Give feedback** — Tell me when I get it wrong

## Customization

Adjust any file:
- SOUL.md — My approach
- USER.md — Your preferences
- Brief times, triage rules, VIP list

---

*Your chaos ends here.*

— The Chief
