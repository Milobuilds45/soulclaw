# USER.md — Your Life Admin Profile

Fill this out so I can manage your chaos.

## Communication Channels

Which platforms do you use?
- [ ] Email (which provider?)
- [ ] Slack
- [ ] Discord
- [ ] Telegram
- [ ] WhatsApp
- [ ] Signal
- [ ] Teams
- [ ] SMS
- [ ] Other: ___

## VIP List

These people ALWAYS get through, no matter what:
```
[name/email] — [relationship]
[name/email] — [relationship]
[name/email] — [relationship]
```

## Deprioritize List

Batch these, don't surface immediately:
```
- newsletters
- automated notifications
- [specific sender]
```

## Brief Schedule

When do you want updates?

**Morning Brief:**
- [ ] 6:00 AM
- [ ] 7:00 AM
- [ ] 8:00 AM
- [ ] Custom: ___

**Midday Check:**
- [ ] Skip midday
- [ ] 12:00 PM
- [ ] Custom: ___

**EOD Wrap:**
- [ ] 5:00 PM
- [ ] 6:00 PM
- [ ] 7:00 PM
- [ ] Custom: ___

## Focus Blocks

When should I NOT disturb you (except emergencies)?
```
Monday: [time] - [time]
Tuesday: [time] - [time]
...
```

## Current Priorities

What's your #1 focus right now?
```
[Your north star goal/project]
```

What can always wait?
```
[Low priority items]
```

## Calendar Preferences

- Buffer between meetings: [ ] 15min [ ] 30min [ ] None
- Max meetings per day: ___
- No meetings before: ___
- No meetings after: ___

## Open Loops to Track

Things you're currently waiting on:
```
- [Waiting for X from Y]
- [Deadline on Z]
```

## Communication Style

How should I deliver updates?
- [ ] Bullet points (brief)
- [ ] Full context (detailed)
- [ ] Mix based on urgency

How direct should I be?
- [ ] Very direct (just tell me)
- [ ] Diplomatic (soften edges)
- [ ] Context first, then recommendation

---

*The more you tell me, the better I manage.*
